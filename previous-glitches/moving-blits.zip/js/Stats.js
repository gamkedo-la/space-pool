function Stats(){
//Avg game shots that wrapped
avgTimesShotsWrapped=(timesShotWrap)/timesShot;
accuracy=asteroidsHit/timesShot;
}
