# space-pool
To run the game, either go to https://gamkedo-la.github.io/space-pool or download the project and open up index.html

To compile a build, or update the github page:

    download node.js (and make sure your PATH is set up correctly)
    In the terminal (or command prompt) navigate to the project folder
    run `npm install` (you only need to do this once)
    then `npm run build`
    commit changes and push to github to deploy to  gamkedo-la.github.io/space-pool

Troubleshooting: 

    if the game does not run locally on your end, try opening the index.html file in the "docs" folder. 




